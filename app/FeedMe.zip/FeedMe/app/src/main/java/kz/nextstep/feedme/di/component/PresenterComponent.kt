package kz.nextstep.feedme.di.component

import dagger.BindsInstance
import dagger.Component
import kz.nextstep.feedme.base.BaseView
import kz.nextstep.feedme.di.module.ContextModule
import kz.nextstep.feedme.di.module.NetworkModule
import kz.nextstep.feedme.ui.post.PostPresenter
import javax.inject.Singleton

/**
 * Component providing inject() methods for presenters.
 */
@Singleton
@Component(modules = [(ContextModule::class), (NetworkModule::class)])
interface PresenterComponent {
    /**
     * Injects required dependencies into the specified PostPresenter.
     * @param postPresenter PostPresenter in which to inject the dependencies
     */
    fun inject(postPresenter: PostPresenter)

    @Component.Builder
    interface Builder {
        fun build(): PresenterComponent

        fun networkModule(networkModule: NetworkModule): Builder
        fun contextModule(contextModule: ContextModule): Builder

        @BindsInstance
        fun baseView(baseView: BaseView): Builder
    }
}